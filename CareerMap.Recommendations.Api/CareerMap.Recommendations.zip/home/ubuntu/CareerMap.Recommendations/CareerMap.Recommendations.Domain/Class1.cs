﻿namespace CareerMap.Recommendations.Domain;

public class Class1
{

}
