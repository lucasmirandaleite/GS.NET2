﻿namespace CareerMap.Recommendations.Infrastructure;

public class Class1
{

}
